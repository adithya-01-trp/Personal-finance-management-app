package com.example.chatapp

class Messages(
    var from: String = "",
    var message: String = "",
    var type: String = "",
    var to: String = "",
    var messageID: String = "",
    var time: String = "",
    var date: String = "",
    var name: String = ""
)
